const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors({
  origin: '*' // Cambiar esto a la URL de tu sitio en producción
}));

// Ruta para recibir los datos del RSVP (método POST)
app.post('/rsvp', (req, res) => {
  const formData = req.body;

  // Validar los datos (opcional)
  if (!formData.fullName || !formData.guestsNumber) {
    return res.status(400).json({ message: 'Nombre completo y número de invitados son requeridos.' });
  }

  // Guardar los datos en un archivo JSON
  fs.appendFile('rsvp_data.json', JSON.stringify(formData) + ',\n', (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Error al guardar los datos.' });
    }

    res.status(200).json({ message: '¡Gracias por confirmar tu asistencia!' });
  });
});

app.listen(PORT, () => {
  console.log(`Servidor escuchando en el puerto ${PORT}`);
});