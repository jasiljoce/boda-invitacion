document.addEventListener('DOMContentLoaded', function () {
    const languageSwitcher = document.querySelector('.language-switcher');
    const langButtons = languageSwitcher.querySelectorAll('button');
    const langElements = document.querySelectorAll('[data-lang]');
    const audio = new Audio('assets/audio/sparks.mp3');
    const playPauseButton = document.getElementById('play-pause');
    const volumeControl = document.getElementById('volume-control');
    const muteUnmuteButton = document.getElementById('mute-unmute');
    
    // Language switcher functionality
    langButtons.forEach(button => {
        button.addEventListener('click', () => {
            const lang = button.getAttribute('data-lang');
            setLanguage(lang);
            localStorage.setItem('preferredLanguage', lang);
        });
    });

    function setLanguage(lang) {
        langButtons.forEach(button => {
            button.classList.toggle('active', button.getAttribute('data-lang') === lang);
        });
        langElements.forEach(element => {
            element.style.display = element.getAttribute('data-lang') === lang ? 'block' : 'none';
        });
    }

    // Initialize language from localStorage
    const preferredLanguage = localStorage.getItem('preferredLanguage') || 'es';
    setLanguage(preferredLanguage);

    // GSAP animations
    gsap.from('#logo', { duration: 1.5, scale: 0.5, ease: 'bounce' });
    gsap.to('.rose', { duration: 2, y: -20, repeat: -1, yoyo: true, ease: 'sine.inOut' });

    // Audio controls
    playPauseButton.addEventListener('click', () => {
        if (audio.paused) {
            audio.play();
            playPauseButton.textContent = 'Pause';
        } else {
            audio.pause();
            playPauseButton.textContent = 'Play';
        }
    });

    volumeControl.addEventListener('input', () => {
        audio.volume = volumeControl.value / 100;
    });

    muteUnmuteButton.addEventListener('click', () => {
        audio.muted = !audio.muted;
        muteUnmuteButton.textContent = audio.muted ? 'Unmute' : 'Mute';
    });

    audio.addEventListener('canplaythrough', () => {
        audio.volume = 0;
        audio.play();
        gsap.to(audio, { duration: 2, volume: volumeControl.value / 100 });
    });

    // Form validation and submission
    const rsvpForm = document.getElementById('rsvp-form');
    const rsvpMessage = document.getElementById('rsvp-message');

    rsvpForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = {
            fullName: rsvpForm['full-name'].value,
            guestsNumber: rsvpForm['guests-number'].value,
            message: rsvpForm['message'].value
        };

        try {
            const response = await fetch(rsvpForm.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            const result = await response.json();
            rsvpMessage.textContent = result.message;
            gsap.fromTo(rsvpMessage, { opacity: 0 }, { duration: 1, opacity: 1 });
        } catch (error) {
            rsvpMessage.textContent = 'Error al enviar el formulario. Por favor, inténtalo de nuevo.';
            gsap.fromTo(rsvpMessage, { opacity: 0 }, { duration: 1, opacity: 1 });
        }
    });

    // QR Code generation
    new QRCode(document.getElementById('qrcode'), {
        text: window.location.href,
        width: 128,
        height: 128
    });
});